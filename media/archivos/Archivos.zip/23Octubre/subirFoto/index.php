<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $(".upload").on('click', function() {
        var formData = new FormData();
        var files = $('#image')[0].files[0];
        formData.append('file',files);
        $.ajax({
            url: 'upload.php',
            type: 'post',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response != 0) {
                    $(".card-img-top").attr("src", response);
                } else {
					alert('Formato de imagen incorrecto.');
				}
            }
        });
		return false;
    });
});
</script>
</head>

<body>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">Subida de imágenes con jQuery y Ajax Demo</li>
        </ol>
    </nav>
    <div class="row">
        <div id="content" class="col-lg-12">
			<form method="post" action="#" enctype="multipart/form-data">
				<div class="card" style="width: 18rem;">
					<img class="card-img-top" src="images/default-avatar.png">
					<div class="card-body">
						<h5 class="card-title">Sube una foto</h5>
						<p class="card-text">Sube una imagen. La imagen puede ser en formato .jpg, o .png.</p>
						<div class="form-group">
							<label for="image">Nueva imagen</label>
							<input type="file" class="form-control-file" name="image" id="image">
						</div>
						<input type="button" class="btn btn-primary upload" value="Subir">
					</div>
				</div>
            </form>
        </div>
    </div>
    
</body>
</html>
